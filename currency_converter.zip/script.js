let rates = {};

const currencies = [
  { code: 'USD', name: '美元' },
  { code: 'TWD', name: '新台幣' },
  { code: 'CNY', name: '人民幣' },
  { code: 'JPY', name: '日圓' },
  { code: 'EUR', name: '歐元' },
  { code: 'GBP', name: '英鎊' },
  { code: 'KRW', name: '韓元' },
  { code: 'HKD', name: '港幣' },
  { code: 'SGD', name: '新加坡幣' },
  { code: 'AUD', name: '澳幣' }
];

const fromCurrency = document.getElementById('fromCurrency');
const toCurrency = document.getElementById('toCurrency');
const amountInput = document.getElementById('amount');

currencies.forEach(c => {
  fromCurrency.innerHTML += `<option value="${c.code}">${c.code} - ${c.name}</option>`;
  toCurrency.innerHTML += `<option value="${c.code}">${c.code} - ${c.name}</option>`;
});
toCurrency.value = 'TWD';

async function fetchRates() {
  try {
    const res = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
    const data = await res.json();
    rates = data.rates;
  } catch {
    rates = { USD:1, TWD:31.5, CNY:7.24, JPY:149.5, EUR:0.92, GBP:0.79 };
  }
  updateRatesGrid();
}

function updateRatesGrid() {
  const grid = document.getElementById('ratesGrid');
  grid.innerHTML = '';
  currencies.slice(1).forEach(c => {
    grid.innerHTML += `
      <div class="rate-card">
        1 USD = ${(rates[c.code] || 0).toFixed(2)} ${c.code}
      </div>`;
  });
}

function convertCurrency() {
  const amount = parseFloat(amountInput.value);
  if (!amount) return alert('請輸入有效金額');

  const fromRate = rates[fromCurrency.value];
  const toRate = rates[toCurrency.value];
  const result = (amount / fromRate) * toRate;

  document.getElementById('resultAmount').textContent = result.toFixed(2) + ' ';
  document.getElementById('resultCurrency').textContent = toCurrency.value;
  document.getElementById('exchangeRate').textContent =
    `1 ${fromCurrency.value} = ${(toRate/fromRate).toFixed(4)} ${toCurrency.value}`;
  document.getElementById('timestamp').textContent =
    new Date().toLocaleString('zh-TW');
  document.getElementById('resultBox').classList.remove('hidden');
}

document.getElementById('convertBtn').onclick = convertCurrency;
document.getElementById('swapBtn').onclick = () => {
  [fromCurrency.value, toCurrency.value] = [toCurrency.value, fromCurrency.value];
};

fetchRates();
